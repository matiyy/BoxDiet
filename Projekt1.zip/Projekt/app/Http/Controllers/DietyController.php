<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DietyController extends Controller
{
    //
}
